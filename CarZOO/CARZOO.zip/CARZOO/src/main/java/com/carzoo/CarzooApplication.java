package com.carzoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarzooApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarzooApplication.class, args);
	}

}
